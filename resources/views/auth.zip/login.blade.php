{{-- <x-guest-layout>
    <form method="POST" action="{{ route('login') }}">
        @csrf

        <!-- Phone Number Only -->
        <div>
            <x-input-label for="phone" :value="__('Phone Number')" />
            <x-text-input id="phone" class="block mt-1 w-full" type="text" name="phone" :value="old('phone')" required
                autofocus />
            <x-input-error :messages="$errors->get('phone')" class="mt-2" />
        </div>

        <div class="flex items-center justify-end mt-4">
            <x-primary-button>
                {{ __('Send OTP') }}
            </x-primary-button>
        </div>
    </form>
</x-guest-layout> --}}



<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8" />
    <meta name="viewport" content="width=device-width, initial-scale=1.0" />
    <title>Login - Bharath Stock Market Research</title>

    <script src="https://cdn.tailwindcss.com"></script>
    <script src="https://cdn.jsdelivr.net/npm/alpinejs@3.x.x/dist/cdn.min.js" defer></script>
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">
</head>

<body class="bg-black">
    <div class="w-full min-h-screen grid md:grid-cols-2">

        <!-- LEFT SIDE IMAGE -->
        <div class="relative w-full h-[300px] md:h-full">
            <img src="https://images.pexels.com/photos/8370754/pexels-photo-8370754.jpeg?auto=compress&cs=tinysrgb&w=1600"
                class="w-full max-h-screen h-full object-cover" />
        </div>

        <!-- RIGHT SIDE FORM -->
        <div class="bg-white flex items-center justify-center px-6 md:px-16 py-12">

            <div class="w-full max-w-md">

                <!-- TITLE -->
                <h1 class="text-3xl font-bold text-black leading-snug">
                    Welcome to Bharath <br> Stock Market Research
                </h1>

                <p class="text-gray-500 text-sm mt-2 mb-8">
                    Login to your Account
                </p>

                <!-- Laravel Login Form -->
                <form method="POST" action="{{ route('login') }}">
                    @csrf

                    <label class="text-gray-700 text-sm font-medium">Mobile Number</label>
                    <input type="tel" name="phone" required value="{{ old('phone') }}"
                        class="w-full border border-gray-300 px-4 py-3 rounded-md mt-2 outline-none"
                        placeholder="Enter 10-digit number">

                    @error('phone')
                        <p class="text-red-600 text-sm mt-2">{{ $message }}</p>
                    @enderror

                    <button class="w-full bg-black text-white py-3 rounded-md mt-6">
                        Send OTP
                    </button>
                </form>

            </div>
        </div>
    </div>
</body>

</html>
